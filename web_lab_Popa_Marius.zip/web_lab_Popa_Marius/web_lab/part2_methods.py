# Laborator: functii, metode si importuri pe web
# Student: Popa Marius

import requests
import time

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10

print("Ex9:")
response = requests.get(BASE_URL, timeout=TIMEOUT)
print(response.status_code)
print(response.ok)
print(response.url)
print(response.encoding)

print("\nEx10:")
try:
    response.raise_for_status()
    print("Pagina principala OK.")
except requests.HTTPError as e:
    print("Eroare HTTP:", e)
time.sleep(1)
try:
    r404 = requests.get(BASE_URL + "/this-page-does-not-exist", timeout=TIMEOUT)
    r404.raise_for_status()
except requests.HTTPError:
    print("Pagina nu a fost gasita. Te rugam sa verifici URL-ul.")

print("\nEx11:")
time.sleep(1)
response11 = requests.get(BASE_URL, timeout=TIMEOUT)
for nume, valoare in response11.headers.items():
    print(f"{nume}: {valoare}")

print("\nEx12:")
time.sleep(1)
response12 = requests.get(BASE_URL, timeout=TIMEOUT)
print("Server:", response12.headers.get("Server", "lipseste"))
print("Content-Type:", response12.headers.get("Content-Type", "lipseste"))
print("content-type (litere mici):", response12.headers.get("content-type", "lipseste"))

print("\nEx13:")
time.sleep(1)
response13 = requests.get(BASE_URL, timeout=TIMEOUT)
count_cyber = response13.text.lower().count("cyber")
print(f"Cuvantul 'cyber' apare de {count_cyber} ori.")

print("\nEx14:")
time.sleep(1)
response14 = requests.get(BASE_URL, timeout=TIMEOUT)
html = response14.text
start = html.find("<title>") + len("<title>")
end = html.find("</title>")
print("Titlu:", html[start:end].strip())

print("\nEx15:")
time.sleep(1)
response15 = requests.get(BASE_URL, timeout=TIMEOUT)
lines = response15.text.splitlines()
print("Numar linii:", len(lines))
print("Lungimea celei mai lungi linii:", len(max(lines, key=len)))

print("\nEx16:")
time.sleep(1)
response16 = requests.get(BASE_URL, timeout=TIMEOUT)
if response16.url.startswith("https://"):
    print("Conexiune securizata")
else:
    print("Conexiune nesecurizata")

print("\nEx17:")
time.sleep(1)
response17 = requests.get("http://cybercor.org", timeout=TIMEOUT)
for r in response17.history:
    print(f"  Redirectionare: {r.status_code} -> {r.url}")
print("URL final:", response17.url)

print("\nEx18:")
time.sleep(1)
response_head = requests.head(BASE_URL, timeout=TIMEOUT)
time.sleep(1)
response_get = requests.get(BASE_URL, timeout=TIMEOUT)
print("Lungime corp HEAD:", len(response_head.content))
print("Lungime corp GET:", len(response_get.content))

print("\nEx19:")
time.sleep(1)
response19 = requests.get(BASE_URL, timeout=TIMEOUT)
if response19.cookies:
    for cookie in response19.cookies:
        print(f"Cookie: {cookie.name}, secure={cookie.secure}")
else:
    print("Niciun cookie setat.")

print("\nEx20:")
time.sleep(1)
session = requests.Session()
session.headers.update({"User-Agent": "WebLab-Popa-Marius"})
response20 = session.get(ECHO_URL + "/headers", timeout=TIMEOUT)
data = response20.json()
print("User-Agent trimis:", data["headers"].get("User-Agent", "negasit"))