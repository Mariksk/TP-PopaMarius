# Laborator: functii, metode si importuri pe web
# Student: Popa Marius

import webtools
from webtools import get_title, security_headers
import argparse
import urllib.parse

print("User-Agent folosit:", webtools.DEFAULT_HEADERS)

parser = argparse.ArgumentParser(description="Raport web pentru un site.")
parser.add_argument("url", nargs="?", default="https://cybercor.org",
                    help="URL-ul site-ului de analizat")
args = parser.parse_args()
TARGET_URL = args.url

print(f"\nURL tinta: {TARGET_URL}")

print("\n--- Ex44 ---")
titlu = webtools.get_title(webtools.fetch(TARGET_URL).text)
print("Titlu (prin webtools):", titlu)

print("\n--- Ex45 ---")
titlu2 = get_title(webtools.fetch(TARGET_URL).text)
print("Titlu (from webtools import):", titlu2)
sec = security_headers(TARGET_URL)
for h, prezent in sec.items():
    print(f"  {h}: {'DA' if prezent else 'NU'}")

print("\n--- Ex49 ---")
parsed = urllib.parse.urlparse(TARGET_URL)
base = f"{parsed.scheme}://{parsed.netloc}"
webtools.save_report_csv(base, ["/", "/robots.txt", "/sitemap.xml"])

print("\n--- Ex50 ---")
webtools.site_report(TARGET_URL)