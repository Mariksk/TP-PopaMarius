# Laborator: functii, metode si importuri pe web
# Student: Popa Marius

import requests
import urllib.request
import time

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10

print("Ex1:")
print("requests version:", requests.__version__)

print("\nEx2:")
response = requests.get(BASE_URL, timeout=TIMEOUT)
print("Stil 1 (import requests) - cod de stare:", response.status_code)
from requests import get
response2 = get(BASE_URL, timeout=TIMEOUT)
print("Stil 2 (from requests import get) - cod de stare:", response2.status_code)

print("\nEx3:")
import requests as rq
response3 = rq.get(BASE_URL, timeout=TIMEOUT)
print("Cu alias rq - cod de stare:", response3.status_code)

print("\nEx4:")
req = urllib.request.Request(BASE_URL, headers={"User-Agent": "WebLab-Popa-Marius"})
with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
    print("Status:", resp.status)
    body = resp.read().decode("utf-8")
    print("Primele 200 caractere din corp:")
    print(body[:200])

print("\nEx5:")
print(dir(requests))

print("\nEx6:")
response6 = requests.get(BASE_URL, timeout=TIMEOUT)
print("Cerere cu timeout=TIMEOUT, status:", response6.status_code)

print("\nEx7:")
start = time.perf_counter()
response7 = requests.get(BASE_URL, timeout=TIMEOUT)
end = time.perf_counter()
print(f"time.perf_counter(): {end - start:.4f} secunde")
print(f"response.elapsed:    {response7.elapsed.total_seconds():.4f} secunde")

print("\nEx8:")
try:
    import bs4
    print("bs4 importat cu succes, versiune:", bs4.__version__)
except ImportError:
    print("Instalati modulul cu: pip install beautifulsoup4")