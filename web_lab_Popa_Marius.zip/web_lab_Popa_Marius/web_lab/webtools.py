# Laborator: functii, metode si importuri pe web
# Student: Popa Marius

import requests
import re
import urllib.parse
import hashlib
import json
import socket
import ssl
import datetime
import csv
import time

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10
DEFAULT_HEADERS = {"User-Agent": "WebLab-Popa-Marius"}

SECURITY_HEADER_LIST = [
    "Strict-Transport-Security",
    "Content-Security-Policy",
    "X-Frame-Options",
    "X-Content-Type-Options",
    "Referrer-Policy",
]

def fetch(url: str, timeout: int = TIMEOUT) -> requests.Response:
    """Descarca URL-ul si returneaza obiectul raspuns."""
    return requests.get(url, timeout=timeout, headers=DEFAULT_HEADERS)

def get_status(url: str) -> int:
    """Returneaza codul de stare HTTP pentru adresa url."""
    return fetch(url).status_code

def get_title(html: str) -> str:
    """Extrage titlul paginii din continutul HTML."""
    start = html.find("<title>") + len("<title>")
    end = html.find("</title>")
    if start > len("<title>") - 1 and end != -1:
        return html[start:end].strip()
    return ""

def page_exists(url: str) -> bool:
    """Returneaza True daca pagina exista, False altfel."""
    try:
        r = fetch(url)
        r.raise_for_status()
        return True
    except requests.RequestException:
        return False

def check_paths(base: str, paths: list) -> dict:
    """Verifica o lista de cai si returneaza {path: status_code}."""
    result = {}
    for path in paths:
        try:
            result[path] = fetch(base + path).status_code
        except requests.RequestException:
            result[path] = None
        time.sleep(1)
    return result

def get_header(url: str, name: str, default: str = "lipseste") -> str:
    """Returneaza valoarea unui antet HTTP specific."""
    return fetch(url).headers.get(name, default)

def security_headers(url: str) -> dict:
    """Verifica prezenta celor 5 antete de securitate principale."""
    r = fetch(url)
    return {h: h in r.headers for h in SECURITY_HEADER_LIST}

def score_headers(results: dict) -> str:
    """Returneaza scorul antetelor de securitate ca sir 'x/5'."""
    return f"{sum(1 for v in results.values() if v)}/{len(results)}"

def fetch_robots(base: str):
    """Descarca robots.txt si returneaza continutul sau None."""
    try:
        r = fetch(base + "/robots.txt")
        r.raise_for_status()
        return r.text
    except requests.RequestException:
        return None

def disallowed_paths(robots_text) -> list:
    """Extrage toate caile Disallow din robots.txt."""
    if robots_text is None:
        return []
    cai = []
    for linie in robots_text.splitlines():
        linie = linie.strip()
        if linie.startswith("Disallow:"):
            cale = linie[len("Disallow:"):].strip()
            if cale:
                cai.append(cale)
    return cai

def extract_links(html: str) -> list:
    """Extrage toate legaturile unice dintr-un sir HTML."""
    toate = re.findall(r'href="([^"]+)"', html)
    vazute = set()
    unice = []
    for link in toate:
        if link not in vazute:
            vazute.add(link)
            unice.append(link)
    return unice

def split_links(links: list, domain: str) -> tuple:
    """Imparte legaturile in interne si externe."""
    interne, externe = [], []
    for link in links:
        url_complet = urllib.parse.urljoin("https://" + domain, link)
        netloc = urllib.parse.urlparse(url_complet).netloc
        if netloc == domain or netloc == "" or netloc.endswith("." + domain):
            interne.append(link)
        else:
            externe.append(link)
    return interne, externe

def resolve(hostname: str) -> str:
    """Returneaza adresa IP a unui hostname."""
    return socket.gethostbyname(hostname)

def cert_days_left(hostname: str) -> int:
    """Returneaza zilele ramase pana la expirarea certificatului SSL."""
    context = ssl.create_default_context()
    with socket.create_connection((hostname, 443), timeout=TIMEOUT) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as ssock:
            cert = ssock.getpeercert()
    expira_ts = ssl.cert_time_to_seconds(cert["notAfter"])
    expira_dt = datetime.datetime.fromtimestamp(expira_ts, tz=datetime.timezone.utc)
    return (expira_dt - datetime.datetime.now(tz=datetime.timezone.utc)).days

def response_times(*urls) -> dict:
    """Returneaza timpii de raspuns pentru URL-urile date."""
    timpi = {}
    for url in urls:
        time.sleep(1)
        start = time.perf_counter()
        try:
            fetch(url)
        except requests.RequestException:
            timpi[url] = None
            continue
        timpi[url] = round(time.perf_counter() - start, 4)
    return timpi

def log(message: str, **details) -> None:
    """Afiseaza un mesaj urmat de detalii cheie=valoare."""
    extras = " | ".join(f"{k}={v}" for k, v in details.items())
    print(f"{message} | {extras}" if extras else message)

def save_report_csv(base: str, paths: list, fisier: str = "report.csv") -> None:
    """Salveaza rezultatul check_paths intr-un fisier CSV."""
    rezultate = check_paths(base, paths)
    acum = datetime.datetime.now().isoformat()
    with open(fisier, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["path", "status", "checked_at"])
        writer.writeheader()
        for path, status in rezultate.items():
            writer.writerow({"path": path, "status": status, "checked_at": acum})
    print(f"Raport CSV salvat in {fisier}")

def site_report(url: str, fisier_json: str = "report.json") -> dict:
    """Genereaza un raport complet al site-ului si il salveaza in JSON."""
    hostname = urllib.parse.urlparse(url).netloc

    r = fetch(url)
    status = r.status_code
    url_final = r.url
    titlu = get_title(r.text)
    time.sleep(1)

    ip = resolve(hostname)
    time.sleep(1)

    r_http = requests.get("http://" + hostname, timeout=TIMEOUT, headers=DEFAULT_HEADERS)
    redirects = [f"{h.status_code} -> {h.url}" for h in r_http.history]
    time.sleep(1)

    sec = security_headers(url)
    scor = score_headers(sec)
    time.sleep(1)

    try:
        zile_cert = cert_days_left(hostname)
    except Exception:
        zile_cert = -1

    legaturi = extract_links(r.text)
    interne, externe = split_links(legaturi, hostname)
    time.sleep(1)

    robots = fetch_robots(url)
    cai_interzise = disallowed_paths(robots)

    raport = {
        "url": url,
        "status_code": status,
        "url_final": url_final,
        "titlu": titlu,
        "ip": ip,
        "redirects": redirects,
        "scor_securitate": scor,
        "zile_certificat": zile_cert,
        "legaturi_interne": len(interne),
        "legaturi_externe": len(externe),
        "cai_interzise": cai_interzise,
        "generat_la": datetime.datetime.now().isoformat(),
    }

    print(f"\n=== Raport site: {url} ===")
    print(f"Cod de stare:      {status}")
    print(f"Titlu:             {titlu}")
    print(f"Adresa IP:         {ip}")
    print(f"Redirectionari:    {', '.join(redirects) if redirects else 'niciuna'}")
    print(f"Scor securitate:   {scor}")
    print(f"Certificat:        {zile_cert} de zile ramase")
    print(f"Legaturi:          {len(interne)} interne, {len(externe)} externe")
    print(f"Cai interzise:     {', '.join(cai_interzise) if cai_interzise else 'niciuna'}")

    with open(fisier_json, "w", encoding="utf-8") as f:
        json.dump(raport, f, indent=2, ensure_ascii=False)
    print(f"Salvat in {fisier_json}")

    return raport

if __name__ == "__main__":
    print("Autotest:", get_status("https://cybercor.org"))