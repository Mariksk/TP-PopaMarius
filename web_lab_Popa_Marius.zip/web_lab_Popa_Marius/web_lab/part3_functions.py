# Laborator: functii, metode si importuri pe web
# Student: Popa Marius

import requests
import time

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10

def fetch(url, timeout=10):
    """Descarca URL-ul si returneaza obiectul raspuns."""
    return requests.get(url, timeout=timeout)

def get_status(url: str) -> int:
    """Returneaza codul de stare HTTP pentru adresa url."""
    return requests.get(url, timeout=TIMEOUT).status_code

def get_title(html: str) -> str:
    """Extrage titlul paginii din continutul HTML."""
    start = html.find("<title>") + len("<title>")
    end = html.find("</title>")
    if start > len("<title>") - 1 and end != -1:
        return html[start:end].strip()
    return ""

def page_exists(url: str) -> bool:
    """Returneaza True daca pagina exista, False altfel."""
    try:
        r = requests.get(url, timeout=TIMEOUT)
        r.raise_for_status()
        return True
    except requests.RequestException:
        return False

def check_paths(base: str, paths: list) -> dict:
    """Verifica o lista de cai si returneaza {path: status_code}."""
    result = {}
    for path in paths:
        try:
            r = requests.get(base + path, timeout=TIMEOUT)
            result[path] = r.status_code
        except requests.RequestException:
            result[path] = None
        time.sleep(1)
    return result

def get_header(url: str, name: str, default: str = "lipseste") -> str:
    """Returneaza valoarea unui antet HTTP specific."""
    r = requests.get(url, timeout=TIMEOUT)
    return r.headers.get(name, default)

SECURITY_HEADERS = [
    "Strict-Transport-Security",
    "Content-Security-Policy",
    "X-Frame-Options",
    "X-Content-Type-Options",
    "Referrer-Policy",
]

def security_headers(url: str) -> dict:
    """Verifica prezenta celor 5 antete de securitate principale."""
    r = requests.get(url, timeout=TIMEOUT)
    return {h: h in r.headers for h in SECURITY_HEADERS}

def score_headers(results: dict) -> str:
    """Returneaza scorul antetelor de securitate ca sir 'x/5'."""
    prezente = sum(1 for v in results.values() if v)
    return f"{prezente}/{len(results)}"

def fetch_robots(base: str):
    """Descarca robots.txt si returneaza continutul sau None."""
    try:
        r = requests.get(base + "/robots.txt", timeout=TIMEOUT)
        r.raise_for_status()
        return r.text
    except requests.RequestException:
        return None

def disallowed_paths(robots_text) -> list:
    """Extrage toate caile Disallow din robots.txt."""
    if robots_text is None:
        return []
    cai = []
    for linie in robots_text.splitlines():
        linie = linie.strip()
        if linie.startswith("Disallow:"):
            cale = linie[len("Disallow:"):].strip()
            if cale:
                cai.append(cale)
    return cai

def response_times(*urls) -> dict:
    """Returneaza un dictionar {url: secunde} cu timpii de raspuns."""
    timpi = {}
    for url in urls:
        time.sleep(1)
        start = time.perf_counter()
        try:
            requests.get(url, timeout=TIMEOUT)
        except requests.RequestException:
            timpi[url] = None
            continue
        timpi[url] = round(time.perf_counter() - start, 4)
    return timpi

def log(message: str, **details) -> None:
    """Afiseaza un mesaj urmat de detalii cheie=valoare."""
    extras = " | ".join(f"{k}={v}" for k, v in details.items())
    print(f"{message} | {extras}" if extras else message)


print("Ex21:")
r = fetch(BASE_URL)
print("Status:", r.status_code)

print("\nEx22:")
for path in ["/", "/robots.txt", "/sitemap.xml"]:
    print(f"{BASE_URL}{path} -> {get_status(BASE_URL + path)}")
    time.sleep(1)

print("\nEx23:")
r_default = fetch(BASE_URL)
print("Cu timeout implicit (10s):", r_default.status_code)
time.sleep(1)
r_custom = fetch(BASE_URL, timeout=3)
print("Cu timeout=3s:", r_custom.status_code)

print("\nEx24:")
time.sleep(1)
print("Titlu:", get_title(fetch(BASE_URL).text))

print("\nEx25:")
help(get_title)

print("\nEx26:")
try:
    rezultat = get_status(123)
    print("Rezultat cu argument int:", rezultat)
except Exception as e:
    print("Eroare:", e)

print("\nEx27:")
time.sleep(1)
print("cybercor.org:", page_exists(BASE_URL))
time.sleep(1)
print("domeniu inexistent:", page_exists("https://this-domain-does-not-exist.invalid"))

print("\nEx28:")
paths_result = check_paths(BASE_URL, ["/", "/robots.txt", "/sitemap.xml"])
for path, status in paths_result.items():
    print(f"  {path}: {status}")

print("\nEx29:")
time.sleep(1)
print("Server:", get_header(BASE_URL, name="Server"))
time.sleep(1)
print("Content-Type:", get_header(BASE_URL, name="Content-Type"))

print("\nEx30:")
time.sleep(1)
sec = security_headers(BASE_URL)
for h, prezent in sec.items():
    print(f"  {h}: {'DA' if prezent else 'NU'}")

print("\nEx31:")
time.sleep(1)
print("Scor antete securitate:", score_headers(security_headers(BASE_URL)))

print("\nEx32:")
robots = fetch_robots(BASE_URL)
cai = disallowed_paths(robots)
print("Cai interzise:", cai if cai else "(niciuna)")

print("\nEx33:")
timpi = response_times(BASE_URL, BASE_URL + "/robots.txt")
for url, t in timpi.items():
    print(f"  {url}: {t}s")

print("\nEx34:")
log("verificat", url=BASE_URL, status=200)
log("eroare detectata", url=BASE_URL + "/missing", status=404)