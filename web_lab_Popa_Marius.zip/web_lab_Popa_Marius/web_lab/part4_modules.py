# Laborator: functii, metode si importuri pe web
# Student: Popa Marius

import requests
import urllib.parse
import re
import html.parser
import hashlib
import json
import socket
import ssl
import datetime
import time

BASE_URL = "https://cybercor.org"
TIMEOUT = 10

print("Ex35:")
parsed = urllib.parse.urlparse("https://cybercor.org/path?x=1#top")
print("scheme:", parsed.scheme)
print("netloc:", parsed.netloc)
print("path:", parsed.path)
print("query:", parsed.query)
print("fragment:", parsed.fragment)

print("\nEx36:")
for leg in ["/about", "contact.html", "../index.html"]:
    print(" ", urllib.parse.urljoin(BASE_URL, leg))

print("\nEx37:")
time.sleep(1)
response37 = requests.get(BASE_URL, timeout=TIMEOUT)
toate = re.findall(r'href="([^"]+)"', response37.text)
vazute = set()
legaturi = []
for l in toate:
    if l not in vazute:
        vazute.add(l)
        legaturi.append(l)
print(f"Legaturi unice gasite: {len(legaturi)}")
for l in legaturi[:5]:
    print(" ", l)

print("\nEx38:")
interne, externe = [], []
for link in legaturi:
    url_complet = urllib.parse.urljoin(BASE_URL, link)
    netloc = urllib.parse.urlparse(url_complet).netloc
    if netloc == "cybercor.org" or netloc == "":
        interne.append(link)
    else:
        externe.append(link)
print(f"Interne: {len(interne)}, Externe: {len(externe)}")

print("\nEx39:")
class ImageFinder(html.parser.HTMLParser):
    def __init__(self):
        super().__init__()
        self.images = []
    def handle_starttag(self, tag, attrs):
        if tag.lower() == "img":
            src = dict(attrs).get("src")
            if src is not None:
                self.images.append(src)

test_html = """
<html><body>
  <img src="/logo.png" alt="Logo">
  <IMG SRC="poza.jpg">
  <img alt="imagine fara src">
  <img src="https://cdn.example.com/banner.webp" />
  <a href="/despre">Aceasta nu este o imagine</a>
</body></html>
"""
finder_test = ImageFinder()
finder_test.feed(test_html)
print(finder_test.images)
assert finder_test.images == ["/logo.png", "poza.jpg", "https://cdn.example.com/banner.webp"]
print("Testul a trecut!")

time.sleep(1)
response39 = requests.get(BASE_URL, timeout=TIMEOUT)
finder_real = ImageFinder()
finder_real.feed(response39.text)
print(f"{len(finder_real.images)} imagini gasite pe site-ul real:")
for src in finder_real.images:
    print(" ", src)

print("\nEx40:")
time.sleep(1)
def page_fingerprint(url):
    """Calculeaza hash-ul SHA-256 al continutului paginii."""
    r = requests.get(url, timeout=TIMEOUT)
    return hashlib.sha256(r.content).hexdigest()

amp1 = page_fingerprint(BASE_URL)
time.sleep(1)
amp2 = page_fingerprint(BASE_URL)
print("Amprenta 1:", amp1)
print("Amprenta 2:", amp2)
print("Identice:", amp1 == amp2)

print("\nEx41:")
time.sleep(1)
r41 = requests.get(BASE_URL, timeout=TIMEOUT)
with open("headers.json", "w", encoding="utf-8") as f:
    json.dump(dict(r41.headers), f, indent=2)
with open("headers.json", "r", encoding="utf-8") as f:
    antete = json.load(f)
print("Content-Type (din JSON):", antete.get("Content-Type", "lipseste"))

print("\nEx42:")
ip = socket.gethostbyname("cybercor.org")
print("Adresa IP cybercor.org:", ip)

print("\nEx43:")
def cert_days_left(hostname):
    """Returneaza zilele ramase pana la expirarea certificatului SSL."""
    context = ssl.create_default_context()
    with socket.create_connection((hostname, 443), timeout=TIMEOUT) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as ssock:
            cert = ssock.getpeercert()
    expira_ts = ssl.cert_time_to_seconds(cert["notAfter"])
    expira_dt = datetime.datetime.fromtimestamp(expira_ts, tz=datetime.timezone.utc)
    acum = datetime.datetime.now(tz=datetime.timezone.utc)
    return (expira_dt - acum).days

print(f"Certificat cybercor.org expira in {cert_days_left('cybercor.org')} zile.")